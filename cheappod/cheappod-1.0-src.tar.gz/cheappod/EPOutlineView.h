/* EPOutlineView */

#import <Cocoa/Cocoa.h>

@interface EPOutlineView : NSOutlineView
{
}


@end
